<?php
/**
 * @file
 * Result of nodes.csv file parsed by ParserCSV.inc
 */

$control_result = array (
  0 =>
  array (
    0 => 'Title',
    1 => 'Body',
    2 => 'published',
    3 => 'GUID',
  ),
  1 =>
  array (
    0 => 'Ut wisi enim ad minim veniam',
    1 => ' Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    2 => '205200720',
    3 => '2',
  ),
  2 =>
  array (
    0 => 'Duis autem vel eum iriure dolor',
    1 => ' Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.',
    2 => '428112720',
    3 => '3',
  ),
  3 =>
  array (
    0 => 'Nam liber tempor',
    1 => ' Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.',
    2 => '1151766000',
    3 => '1',
  ),
  4 =>
  array (
    0 => 'Typi non habent',
    1 => ' Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem.',
    2 => '1256326995',
    3 => '4',
  ),
  5 =>
  array (
    0 => 'Lorem ipsum',
    1 => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
    2 => '1251936720',
    3 => '1',
  ),
  6 =>
  array (
    0 => 'Investigationes demonstraverunt',
    1 => ' Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius.',
    2 => '946702800',
    3 => '5',
  ),
  7 =>
  array (
    0 => 'Claritas est etiam',
    1 => ' Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.',
    2 => '438112720',
    3 => '6',
  ),
  8 =>
  array (
    0 => 'Mirum est notare',
    1 => ' Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima.',
    2 => '1151066000',
    3 => '7',
  ),
  9 =>
  array (
    0 => 'Eodem modo typi',
    1 => ' Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.',
    2 => '1201936720',
    3 => '8',
  ),
);
