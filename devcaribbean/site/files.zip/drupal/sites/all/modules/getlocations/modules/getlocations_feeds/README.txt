Getlocations Feeds provides support for the Feeds module and its Importer functions.
