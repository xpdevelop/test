Getlocations Location Taxonomize provides support for the Location Taxonomize module.

Make sure you enable it under
content types >
your content type >
Manage fields >
Getlocations Fields > edit

see http://drupal.org/node/1818864 for a detailed explanation on how to set this up.

