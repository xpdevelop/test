/** Automatically generated file. DO NOT MODIFY */
package net.learntodevelop.json;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}