/*package net.learntodevelop.json;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class JsonactivityActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.jsonactivity);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jsonactivity, menu);
		return true;
	}

}
*/



package net.learntodevelop.json;
 
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
 
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;
 
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.Toast;
 
public class JsonactivityActivity extends Activity {
 
    public String readJSONFeed(String URL) {
        StringBuilder stringBuilder = new StringBuilder();
        HttpClient httpClient = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(URL);
        try {
            HttpResponse response = httpClient.execute(httpGet);
            StatusLine statusLine = response.getStatusLine();
            int statusCode = statusLine.getStatusCode();
            if (statusCode == 200) {
                HttpEntity entity = response.getEntity();
                InputStream inputStream = entity.getContent();
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(inputStream));
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                inputStream.close();
            } else {
                //Log.d("JSON", "Failed to download file");
            }
        } catch (Exception e) {
            return jsoncrimes;
        }        
        return stringBuilder.toString();
    }
    
    
    private class ReadWeatherJSONFeedTask extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            return readJSONFeed(urls[0]);
        }
 
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObject = new JSONObject(result);
                JSONObject weatherObservationItems = 
                    new JSONObject(jsonObject.getString("weatherObservation"));
 
                Toast.makeText(getBaseContext(), 
                    weatherObservationItems.getString("clouds") + 
                 " - " + weatherObservationItems.getString("stationName"), 
                 Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.d("ReadWeatherJSONFeedTask", e.getLocalizedMessage());
            }          
        }
    }
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jsonactivity);
    }
    
    public void btnGetPlaces(View view)throws Exception{
    	EditText lattitude = (EditText)findViewById(R.id.txtLat);
    	EditText longitude = (EditText)findViewById(R.id.txtLong);
    	if(lattitude.getText().toString().equals("0") && longitude.toString().equals("0")){
    		Toast.makeText(this, "Not a caribbean location", 5000);
    	}    	
    	//URL url = new URL();
    	try {
    		String result = readJSONFeed("http://10.36.81.129/drupal/data-crimes-service/crimedata/"
    		    	+lattitude.getText().toString()+"/"+longitude.getText().toString() + ".json");    			
    		    	JSONObject jsonObject = new JSONObject(result);
    		        //JSONObject weatherObservationItems = new JSONObject(jsonObject.getString("status"));
    		    	int a = new Integer(jsonObject.getString("status"));
    		    	String zone = "";
    		    	switch(a){
    		    	case 1:{
    		    		zone = "Dangeorus";
    		    		break;
    		    	}
    		    	case 2:{
    		    		zone = "Middle Dangeorus";
    		    		break;
    		    	}
    		    	case 3:{
    		    		zone = "Safe";
    		    		break;
    		    	}
    		    	default:{
    		    		zone = "Not related information";
    		    	}
    		    	}
    		        Toast.makeText(getBaseContext(),zone, 
    		         Toast.LENGTH_SHORT).show();  
    		        JSONArray arr = jsonObject.getJSONArray("crimes");
    		        EditText crimes = (EditText)findViewById(R.id.editText1);
    		        crimes.setText(arr.toString());
		} catch (Exception e) {
			Toast.makeText(getBaseContext(), "Unable to stablish connection with the service", 5000);
		}
    	
    }
    
    public void btnGetWeather(View view){
    	Toast.makeText(this, "1", 5000).show();
    }
    
    String jsoncrimes = "{\"status\":3,\"crimes\":[{\"period\":2013,\"minor_crimes\":3,\"serious_crimes\":1},{\"period\":1955,\"minor_crimes\":9078,\"serious_crimes\":1908},{\"period\":1966,\"minor_crimes\":11991,\"serious_crimes\":4048},{\"period\":1985,\"minor_crimes\":15756,\"serious_crimes\":13979},{\"period\":2007,\"minor_crimes\":14217,\"serious_crimes\":19661},{\"period\":1978,\"minor_crimes\":7298,\"serious_crimes\":9888},{\"period\":1956,\"minor_crimes\":8621,\"serious_crimes\":1871},{\"period\":1993,\"minor_crimes\":21946,\"serious_crimes\":19458},{\"period\":1951,\"minor_crimes\":10920,\"serious_crimes\":2336},{\"period\":1998,\"minor_crimes\":19930,\"serious_crimes\":15796},{\"period\":1969,\"minor_crimes\":12031,\"serious_crimes\":5206}]}";
 
}